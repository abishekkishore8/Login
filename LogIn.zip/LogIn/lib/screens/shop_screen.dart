import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:login/model/shopitem_model.dart';
import 'package:login/screens/item_details.dart';

class shop extends StatefulWidget {
  const shop({Key? key}) : super(key: key);
  @override
  _shopState createState() => _shopState();
}

class _shopState extends State<shop> {


  Widget shopItems({required Function()? onTap,required String image,required String name,required int price,}){
    return Padding(
      padding: const EdgeInsets.all(10),
      child: GestureDetector(
        onTap:onTap,
        child: Container(
          height:270,
          width: 220,
          decoration: BoxDecoration(
            color: Colors.black38,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius:70,
                backgroundImage: NetworkImage(image),
              ),
              ListTile(leading: Text(name, style: TextStyle(fontSize:20,color:Colors.white,fontWeight:FontWeight.w700),
              ),
                trailing: Text("\$ $price",style: TextStyle(fontSize:25,color: Colors.white,fontWeight:FontWeight.w500),),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Row(
                  children: [
                    Icon(Icons.star,color: Colors.white,size:15),
                    Icon(Icons.star,color: Colors.white,size:15),
                    Icon(Icons.star,color: Colors.white,size:15),
                    Icon(Icons.star,color: Colors.white,size:15),
                    Icon(Icons.star,color: Colors.white,size:15),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
        icon: Icon(Icons.arrow_back_ios),
         onPressed: (){Navigator.pop(context,true);}
            ),
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0.5,
        title: Text("Shop",style: TextStyle(color: Colors.black54),),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
        .collection("shopItem")
        .snapshots(),
        builder: (context,AsyncSnapshot<QuerySnapshot> streamSnapshot){
          if (!streamSnapshot.hasData){
            return Center(child: const CircularProgressIndicator(),);
          }
          return GridView.builder(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            primary:false,
            physics: BouncingScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                childAspectRatio: 0.8,
                crossAxisCount: 2,
                crossAxisSpacing: 2.0,
                mainAxisSpacing: 2.0,
            ),
            itemCount: streamSnapshot.data!.docs.length,
            itemBuilder: (context,index){
            return shopItems(
                image: streamSnapshot.data!.docs[index]["image"],
                name: streamSnapshot.data!.docs[index]["name"], 
                price: streamSnapshot.data!.docs[index]["price"],
                onTap: (){
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder:(context) => streamSnapshot.data!.docs[index]["image"],),);
                }

            );
          },
            );
        },
      ),
      );
  }
}