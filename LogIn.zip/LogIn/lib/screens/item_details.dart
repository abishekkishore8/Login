import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:login/screens/shop_screen.dart';

class itemDetails extends StatelessWidget {
final String productImage;

  const itemDetails({Key? key, required this.productImage,}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(Icons.arrow_back_ios),
            onPressed: () {Navigator.pop(context);}
        ),
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0.5,
        title: Text("Shop",style: TextStyle(color: Colors.black54),),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Column(
        children:[
          Expanded(
            child: Container(
              child: CircleAvatar(
                radius:110,
               // backgroundImage: NetworkImage(image),
              )
            ),
          ),
          Expanded(
            flex:2,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              width:double.infinity,
              decoration:BoxDecoration(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children:[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("name",style: TextStyle(fontSize:40, color: Colors.black54),),

                      Text("\$ 123",style: TextStyle(fontSize:30, color: Colors.black54),),
                    ],
                  ),
                  Text("Discover Best App Developers Australia. Find Quick Results from Multiple Sources. Get Best App Developers Australia. Get Instant Quality Results at iZito Now! Explore the Best Info Now. Powerful and Easy to Use. 100+ Qualitative Results. Discover Quality Results."
                  , style: TextStyle(fontSize:15, color: Colors.black54),),
                  Container(
                    height: 55,
                    width: double.infinity,
                    child: RaisedButton(onPressed:(){},
                    color:Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:[
                        Icon(Icons.shopping_cart,color: Colors.white),
                        SizedBox(width:10),
                        Text("Add to Cart",style: TextStyle(fontSize:20,color:Colors.white),)
                      ]
                    ) 
                    ),
                  ),
                    ],

              ),

            ),
          ),
        ]
      )
    );
  }

  RaisedButton({required Null Function() onPressed, required MaterialAccentColor color, required RoundedRectangleBorder shape, required Row child}) {}
}
