import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login/model/user_model.dart';
import 'package:login/screens/shop_screen.dart';

import 'login_screen.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  User? user = FirebaseAuth.instance.currentUser;
  UserModel loggedInUser = UserModel();
  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection("users")
        .doc(user!.uid)
        .get()
        .then((value) {
      this.loggedInUser = UserModel.fromMap(value.data());
      setState(() {});
    });
  }
  Widget drawerItem( {required IconData icon, required String name, required Object ontap()}){
    return  GestureDetector(
      onTap: ontap,
      child: ListTile(
        leading: Icon(
          icon,
          color: Colors.black,
        ),
        title: Text(
          name,
          style: TextStyle(fontSize: 18,color: Colors.black),
        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0.5,
          title: Text("Welcome",style: TextStyle(color: Colors.black54),),
          backgroundColor: Colors.white,
      centerTitle: true,
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.cover,
                  image: AssetImage('assets/team.jpg'),
                ),
                ),
                currentAccountPicture: CircleAvatar(
                  backgroundImage: AssetImage('assets/team.jpg'),
                ),
                accountName:Text("${loggedInUser.firstName} ${loggedInUser.secondName}",
                  style: TextStyle(color: Colors.black54, fontWeight:FontWeight.w500, fontSize:20),
                ),
                accountEmail:  Text("${loggedInUser.email}",
                  style: TextStyle(color: Colors.black54, fontWeight:FontWeight.w500,),
                ),
              ),
              drawerItem(
                  icon: Icons.person,
                  name: "Profile",
                  ontap: () async {  } ),
              drawerItem(
                  icon: Icons.shopping_bag,
                  name: "Orders", ontap: () async {} ),
              drawerItem(
                  icon: Icons.shopping_cart,
                  name: "Shop", ontap: () async {Navigator.push(context, MaterialPageRoute(
                  builder: (context) => shop
                    ()),);} ),
              drawerItem(
                  icon: Icons.logout,
                  name: "Logout", ontap: () async {logout(context);  }
              ),
              Divider(
                thickness: 2,
                color: Colors.black26,
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> logout(BuildContext context) async
  {
    await FirebaseAuth.instance.signOut();
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => LoginScreen()));
  }
}
