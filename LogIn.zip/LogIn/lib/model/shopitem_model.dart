import 'package:cloud_firestore/cloud_firestore.dart';

class ShopItemModle{
  String image;
  String name;
  int price;

 ShopItemModle({required this.image,required this.name,required this.price});
  factory ShopItemModle.fromMap(map)
  {
    return ShopItemModle(
      image: map['image'],
      name: map['name'],
      price: map['price'],
    );
  }

}